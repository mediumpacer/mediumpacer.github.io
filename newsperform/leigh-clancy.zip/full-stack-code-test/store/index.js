import * as Filters from '~/helpers/filters'

export const state = () => ({
    locations: [],
    filteredLocations: [],
    activeLocation: {},
    isLoading: false,
    requestDate: new Date(),
    orderBy: 'A-Z',
    filterBy: {
        country: {
            label: 'Country',
            selected: '',
            options: []
        },
        condition: {
            label: 'Weather Condition',
            selected: '',
            options: []
        }
    },
    activeFilters: 0,
    isFiltersOpen: false
})

export const mutations = {
    SET_WEATHER_DATA (state, payload) {
        state.locations = payload.data.filter((location) => {
            return location._weatherTemp && location._weatherLastUpdated // filter out locations with no temperature or time updated
        })
        state.requestDate = payload.date
    },

    SET_IS_LOADING (state, payload) {
        state.isLoading = payload
    },

    SET_FILTER_DATA (state, payload) {
        state.filterBy.country.options = payload.countries
        state.filterBy.condition.options = payload.conditions
    },

    TOGGLE_FILTERS (state, payload) {
        if (payload === 'close') {
            state.isFiltersOpen = false
        } else {
            state.isFiltersOpen = !state.isFiltersOpen
        }
    },

    SET_SORT_OPTION (state, payload) {
        state.orderBy = payload
    },

    SET_FILTER_OPTION (state, payload) {
        let activeFilters = state.activeFilters

        if (!payload.selected) {
            activeFilters--
        } else if (!state.filterBy[payload.filter].selected && payload.selected) {
            activeFilters++
        }

        state.filterBy[payload.filter].selected = payload.selected
        state.activeFilters = activeFilters
    },

    SORT_LOCATIONS (state) {
        const locations = [...state.filteredLocations]
        state.filteredLocations = Filters.orderLocations(locations, state.orderBy)
    },

    FILTER_LOCATIONS (state) {
        const locations = [...state.locations]
        state.filteredLocations = Filters.filterLocations(locations, state.filterBy)
    },

    SET_ACTIVE_LOCATION (state, payload) {
        state.activeLocation = payload
    }
}

export const actions = {
    async getWeatherData ({ commit, dispatch }) {
        commit('SET_IS_LOADING', true)

        const weatherData = await fetch('http://dnu5embx6omws.cloudfront.net/venues/weather.json')
            .then(res => res.json())
            .catch(err => console.error(err)) // eslint-disable-line
        const dataDate = new Date()

        commit('SET_WEATHER_DATA', { data: weatherData.data, date: dataDate })
        dispatch('getFilterData')
        dispatch('filterLocations')
        commit('SET_IS_LOADING', false)
    },

    async getFilterData ({ commit, state }) {
        let countryData = []
        let conditionData = []

        countryData = [...new Set(state.locations.map(loc => loc._country._name))]
            .filter(item => item !== undefined)
            .sort(function (a, b) {
                return a < b ? -1 : 1
            })
        conditionData = [...new Set(state.locations.map(loc => loc._weatherCondition))]
            .filter(item => item !== undefined)
            .sort(function (a, b) {
                return a < b ? -1 : 1
            })

        const filterData = {
            countries: countryData,
            conditions: conditionData
        }

        await commit('SET_FILTER_DATA', filterData)
    },

    async setSortOption ({ commit }, order) {
        await commit('SET_SORT_OPTION', order)
        await commit('SORT_LOCATIONS')
    },

    async setFilterOption ({ commit }, options) {
        await commit('SET_FILTER_OPTION', options)
        await commit('FILTER_LOCATIONS')
        await commit('SORT_LOCATIONS')
    },

    async filterLocations ({ commit }) {
        await commit('FILTER_LOCATIONS')
        await commit('SORT_LOCATIONS')
    },

    async toggleFilters ({ commit }, isOpen) {
        await commit('TOGGLE_FILTERS', isOpen)
    },

    async setActiveLocation ({ commit }, location) {
        await commit('SET_ACTIVE_LOCATION', location)
    }
}

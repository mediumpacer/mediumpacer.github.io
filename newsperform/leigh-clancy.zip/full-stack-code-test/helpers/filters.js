export function orderLocations (locations, orderBy) {
    const orderedList = [...locations]

    if (orderBy === 'Last updated') {
        orderedList.sort(function (a, b) {
            const dateA = a._weatherLastUpdated
            const dateB = b._weatherLastUpdated
            return dateB < dateA ? -1 : 1
        })
    } else if (orderBy === 'Temperature') {
        orderedList.sort(function (a, b) {
            const tempA = parseInt(a._weatherTemp)
            const tempB = parseInt(b._weatherTemp)
            return tempA < tempB ? -1 : 1
        })
    } else {
        orderedList.sort(function (a, b) {
            const nameA = a._name
            const nameB = b._name
            return nameA < nameB ? -1 : 1
        })
    }

    return orderedList
}

export function filterLocations (locations, filterBy) {
    let filteredList = [...locations]

    if (filterBy.country.selected) {
        const theList = filteredList.filter(loc => loc._country._name === filterBy.country.selected)
        filteredList = theList
    }

    if (filterBy.condition.selected) {
        const theList = filteredList.filter(loc => loc._weatherCondition === filterBy.condition.selected)
        filteredList = theList
    }

    return filteredList
}

<template>
    <div class="weather">
        <Nuxt />
    </div>
</template>

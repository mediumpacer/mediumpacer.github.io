<template>
    <div class="weather__container">
        <WeatherHeader />
        <WeatherLoader />
        <section v-if="location" class="weather__body">
            <div class="weather-location">
                <div class="weather-location__inner">
                    <h2 class="weather-location__name">
                        {{ location._name }}
                    </h2>
                    <p v-if="location._weatherCondition" class="weather-location__condition">
                        {{ location._weatherCondition }}
                    </p>
                </div>
                <div class="weather-location__temp">
                    {{ location._weatherTemp }}&deg;
                </div>
            </div>
            <div class="weather-location__details">
                <div v-if="location._weatherFeelsLike" class="weather-location__details-item">
                    <h3 class="weather-location__details-label">
                        Feels Like
                    </h3>
                    <p class="weather-location__details-value">
                        {{ location._weatherFeelsLike }}&deg;
                    </p>
                </div>
                <div v-if="location._weatherHumidity" class="weather-location__details-item">
                    <h3 class="weather-location__details-label">
                        Humidity
                    </h3>
                    <p class="weather-location__details-value">
                        {{ location._weatherHumidity }}
                    </p>
                </div>
                <div v-if="location._weatherWind" class="weather-location__details-item">
                    <h3 class="weather-location__details-label">
                        Wind
                    </h3>
                    <p class="weather-location__details-value">
                        {{ location._weatherWind }}
                    </p>
                </div>
            </div>
            <div class="weather-location__updated">
                Last updated: {{ $moment(location._weatherLastUpdated).format('h:mma DD MMMM YYYY') }}
            </div>
        </section>
    </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
    data () {
        return {}
    },
    computed: {
        ...mapState({
            location (state) {
                const activeId = this.$route.params.id
                const activeLocation = state.locations.find(loc => loc._venueID === activeId)
                return activeLocation
            }
        })
    },
    mounted () {
        this.$store.dispatch('getWeatherData')
    }
}
</script>

<style lang="scss" scoped>
    .weather {
        &__body {
            min-height: calc(100vh - 10rem);
        }

        &__loader {
            top: 14rem;
        }

        &-location {
            &__details,
            &__updated {
                padding: 1rem;
            }

            &__details {
                display: flex;
                justify-content: space-between;
                flex-direction: column;

                &-item {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    padding: 1rem;
                    border-bottom: 1px solid $grey-light;

                    &:last-child {
                        border-bottom: 0;
                    }
                }

                &-label {
                    margin-bottom: 0.5rem;
                    font-size: 1.2rem;
                }

                &-value {
                    color: $cyan;
                    font-size: 1.2rem;
                }

                @media (min-width: $mq-small) {
                    flex-direction: row;

                    &-item {
                        padding: 0;
                        border-bottom: 0;
                    }
                }
            }

            &__updated {
                text-align: center;
                border-top: 1px solid $grey-light;
            }
        }
    }
</style>

<template>
    <div class="weather__container" :class="{'weather__container--locked' : isFiltersOpen }">
        <WeatherHeader />

        <section class="weather__body">
            <WeatherSort />
            <WeatherList />
            <WeatherFilter />
        </section>
    </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
    data () {
        return {}
    },
    computed: {
        ...mapState({
            isFiltersOpen: state => state.isFiltersOpen
        })
    },
    mounted () {
        this.$store.dispatch('getWeatherData')
    }
}
</script>

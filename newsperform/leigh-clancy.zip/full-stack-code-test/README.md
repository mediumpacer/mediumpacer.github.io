# Leigh Clancy's Weather App 

## Installation:
npm version 6.14.5 was used to build this app

```bash
# install dependencies
$ npm install

# serve with hot reload for development at localhost:3000
$ npm run dev

# build for production and launch server at localhost:3000
$ npm run build
$ npm run start
```

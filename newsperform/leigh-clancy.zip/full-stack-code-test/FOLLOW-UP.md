# Leigh Clancy's Weather App - Follow up questions

## 1. What libraries did you add? What are they used for?

sass, sass-loader, node-sass:
    - SASS is my preferred CSS preprocessor language, these modules made developing with SASS in nuxt / vue easier.

nuxtjs/moment
    - Makes date manipulation easier, may have been overkill for the 2 instances its used here

eslint / stylelint 
    - helped keep coding style consistent

## 2. If you had more time, what further improvements or new features would you add?
   - Would look into implementing a more pleasing desktop viewport design
   - Filters: Would come up with a more robust selection / deselection method for the filters in case any future ones would have to be added.
   - Document javascript functions using JSDoc syntax

## 3. Which parts are you most proud of? And why?

Hard to say really, probably the sorting / filtering of the locations just because its required a bit of thought to work out.

## 4. Which parts did you spend the most time with? What did you find most difficult?
    
I think I spent the most time with the filters logic which was a challenge in figuring out the order of sorting the locations out.

## 5. How did you find the test overall? Did you have any issues or have difficulties completing? If you have any suggestions on how we can improve the test, we'd love to hear them.
    
I found the test to be fine with no major issues or difficulties completing it. 
    
I'd ended up creating an individual location/suburb weather page also which may have been outside the tasks remit as its in the design but not in the user stories. 
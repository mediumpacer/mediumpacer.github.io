<template>
    <div class="weather-sort__option" :class=" {'weather-sort__option--selected' : isSelected }" @click="selectSortOption">
        {{ name }}
    </div>
</template>

<script>
export default {
    props: {
        name: {
            type: String,
            default: ''
        },
        selectedSortOption: {
            type: String,
            default: ''
        }
    },
    computed: {
        isSelected () {
            return this.name === this.selectedSortOption
        }
    },
    methods: {
        selectSortOption () {
            this.$emit('selectSortOption', this.name)
        }
    }
}
</script>

<style lang="scss" scoped>
    .weather-sort {
        &__option {
            padding: 1.5rem;
            cursor: pointer;
            font-size: 1.2rem;

            &--selected {
                position: relative;

                &::after {
                    content: '';
                    display: block;
                    position: absolute;
                    bottom: -2px;
                    left: 0;
                    width: 100%;
                    border-bottom: 2px solid $cyan;
                }
            }

            @media (min-width: $mq-small) {
                font-size: 1.6rem;
            }
        }
    }
</style>

<template>
    <nav class="weather-sort">
        <WeatherSortOption
            v-for="option in options"
            :key="option"
            :name="option"
            :selected-sort-option="selectedSortOption"
            @selectSortOption="selectOption"
        />
    </nav>
</template>

<script>
export default {
    data () {
        return {
            options: [
                'A-Z', 'Temperature', 'Last updated'
            ]
        }
    },
    computed: {
        selectedSortOption: {
            get () {
                return this.$store.state.orderBy
            },
            set (option) {
                this.$store.dispatch('setSortOption', option)
            }
        }
    },
    methods: {
        selectOption (option) {
            this.selectedSortOption = option
        }
    }
}
</script>

<style lang="scss" scoped>
    .weather-sort {
        display: flex;
        border-bottom: 2px solid $grey-light;
        margin-bottom: -2px;
    }
</style>

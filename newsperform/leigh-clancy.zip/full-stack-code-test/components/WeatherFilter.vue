<template>
    <div class="weather-filters" :class="{ 'weather-filters--open' : isFiltersOpen }">
        <button class="weather-filters__close" @click="toggleFilters('close')" />
        <div class="weather-filters__header" @click="toggleFilters">
            Filter
            <span v-if="activeFiltersCount" class="weather-filters__count">{{ activeFiltersCount }}</span>
        </div>

        <div class="weather-filters__content">
            <WeatherFilterCategory
                v-for="(value, filterName) in filters"
                :key="filterName"
                :name="filterName"
            />
        </div>
    </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
    computed: {
        ...mapState({
            filters: state => state.filterBy,
            activeFiltersCount: state => state.activeFilters,
            isFiltersOpen: state => state.isFiltersOpen
        })
    },

    methods: {
        toggleFilters (close) {
            this.$store.dispatch('toggleFilters', close)
        }
    }
}
</script>

<style lang="scss" scoped>
    .weather-filters {
        $this: &;

        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background: $white;
        border-top: 1px solid $grey-light;
        height: 5rem;
        transition: height 0.3s ease-in;

        &__header {
            padding: 0 1.5rem;
            height: 5rem;
            border-bottom: 1px solid $grey-light;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
        }

        &__count {
            background: $cyan;
            color: $white;
            border-radius: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            width: 2.4rem;
            height: 2.4rem;
            margin-left: 0.5rem;
        }

        &__content {
            display: none;
            height: calc(100vh - 5rem);
            overflow-y: scroll;
            width: 90vw;
            width: clamp(16rem, 90vw, 70rem);
            margin: 0 auto;
            padding: 0 1.5rem;
        }

        &__close {
            display: none;
            position: absolute;
            top: -4rem;
            left: calc((100% - 90vw) / 2);
            width: 3rem;
            height: 3rem;
            background: transparent;
            border: 0;
            cursor: pointer;
            overflow: hidden;

            &::before {
                display: inline-block;
                content: "\00d7";
                color: $white;
                font-size: 4rem;
                line-height: 3rem;
            }

            @media (min-width: $mq-med) {
                left: calc(((100% - 70rem) / 2) + 1rem);
            }
        }

        &--open {
            height: calc(100vh - 5rem);

            #{$this} {
                &__content {
                    display: block;
                    overflow-y: scroll;
                }

                &__close {
                    display: block;
                }
            }
        }
    }
</style>

<template>
    <div class="weather-filter__option" :class=" {'weather-filter__option--selected' : isSelected }" @click="selectFilterOption">
        {{ name }}
    </div>
</template>

<script>
export default {
    props: {
        name: {
            type: String,
            default: ''
        },
        selectedFilterOption: {
            type: String,
            default: ''
        }
    },
    computed: {
        isSelected () {
            return this.name === this.selectedFilterOption
        }
    },
    methods: {
        selectFilterOption () {
            if (this.name === this.selectedFilterOption) {
                this.$emit('selectFilterOption', '')
            } else {
                this.$emit('selectFilterOption', this.name)
            }
        }
    }
}
</script>

<style lang="scss" scoped>
    .weather-filter {
        &__option {
            padding: 1.5rem 2.5rem;
            cursor: pointer;
            border-bottom: 1px solid $grey-light;

            &--selected {
                background: rgba($cyan, 0.1);
                position: relative;

                &::after {
                    $borderWidth: 4px;
                    $borderColor: $cyan;

                    content: '';
                    position: absolute;
                    right: 3rem;
                    top: 20%;
                    display: block;
                    transform: rotate(45deg);
                    height: 16px;
                    width: 8px;
                    border-bottom: $borderWidth solid $borderColor;
                    border-right: $borderWidth solid $borderColor;
                }
            }
        }
    }
</style>

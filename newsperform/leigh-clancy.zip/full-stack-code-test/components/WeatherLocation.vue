<template>
    <div class="weather-location">
        <div class="weather-location__inner">
            <h2 class="weather-location__name">
                <nuxt-link :to="`/location/${location._venueID}`">
                    {{ location._name }}
                </nuxt-link>
            </h2>
            <p v-if="location._weatherCondition" class="weather-location__condition">
                {{ location._weatherCondition }}
            </p>
            <p class="weather-location__updated">
                Last updated: {{ $moment(location._weatherLastUpdated).format('h:mma DD MMMM YYYY') }}
            </p>
        </div>
        <div class="weather-location__temp">
            {{ location._weatherTemp }}&deg;
        </div>
    </div>
</template>

<script>
export default {
    props: {
        location: {
            type: Object,
            default () { }
        }
    }
}
</script>

<template>
    <div class="weather-list">
        <WeatherLoader />

        <WeatherLocation
            v-for="location in locations"
            :key="location._venueID"
            :location="location"
        />

        <p class="weather-list__notice" :class="{ 'weather-list__notice--show' : locations.length === 0 && !isLoading}">
            Sorry there are no locations available.
        </p>
    </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
    computed: {
        ...mapState({
            locations: state => state.filteredLocations,
            isLoading: state => state.isLoading
        })
    }
}
</script>

<style lang="scss" scoped>
    .weather-list {
        &__notice {
            margin: 2rem 0;
            display: none;

            &--show {
                display: block;
            }
        }
    }
</style>

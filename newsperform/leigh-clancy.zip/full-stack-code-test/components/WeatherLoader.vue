<template>
    <div v-if="isLoading" class="weather-loader">
        <div class="weather-loader__spinner">
            <div class="weather-loader__dot weather-loader__dot--1" />
            <div class="weather-loader__dot weather-loader__dot--2" />
            <div class="weather-loader__dot weather-loader__dot--3" />
            <div class="weather-loader__dot weather-loader__dot--4" />
            <div class="weather-loader__dot weather-loader__dot--5" />
        </div>
        <span class="weather-loader__label">
            Loading...
        </span>
    </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
    computed: {
        ...mapState({
            isLoading: state => state.isLoading
        })
    }
}
</script>

<style lang="scss" scoped>
    .weather-loader {
        display: flex;
        align-items: center;
        justify-content: center;
        height: calc(100vh - 14rem);
        width: 100%;
        top: 0;
        left: 0;
        position: absolute;
        background: rgba($white, 0.7);
        z-index: 100;

        &__spinner {
            position: relative;
            border-radius: 50%;
            width: 3rem;
            height: 3rem;
            animation: spinner 1s linear 0s infinite;
            background-image: linear-gradient(to bottom, $cyan, rgba($cyan, 0.15));

            &::before,
            &::after {
                content: '';
                position: absolute;
                z-index: 1;
                background-color: $white;
            }

            &::before {
                top: 0;
                right: 50%;
                bottom: 0;
                left: 0;
            }

            &::after {
                top: 50%;
                left: 50%;
                width: 2.4rem;
                height: 2.4rem;
                transform: translate(-50%, -50%);
                border-radius: 50%;
            }
        }

        &__dot {
            position: absolute;
            width: 0.3rem;
            height: 0.3rem;
            border-radius: 50%;
            z-index: 2;
            background-color: $cyan;

            &--1 {
                bottom: 1px;
                left: 8px;
                opacity: 0.2;
            }

            &--2 {
                bottom: 6px;
                left: 2px;
                opacity: 0.15;
            }

            &--3 {
                top: 13px;
                left: 0;
                opacity: 0.1;
            }

            &--4 {
                top: 6px;
                left: 2px;
                opacity: 0.05;
            }

            &--5 {
                top: 1px;
                left: 8px;
                opacity: 0;
            }
        }

        &__label {
            margin-left: 1.2rem;
        }
    }

    @keyframes spinner {
        from {
            transform: rotate(0deg);
        }

        to {
            transform: rotate(-360deg);
        }
    }
</style>

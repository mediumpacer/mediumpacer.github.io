<template>
    <div class="weather-filters__category">
        <h3 class="weather-filters__label">
            {{ label }}
        </h3>
        <div class="weather-filters__options">
            <WeatherFilterOption
                v-for="option in options"
                :key="option"
                :name="option"
                :selected-filter-option="selectedFilterOption"
                @selectFilterOption="selectFilterOption"
            />
        </div>
    </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
    props: {
        name: {
            type: String,
            default: ''
        }
    },
    computed: {
        ...mapState({
            label (state) {
                return state.filterBy[this.name].label
            },
            options (state) {
                return state.filterBy[this.name].options
            }
        }),
        selectedFilterOption: {
            get () {
                return this.$store.state.filterBy[this.name].selected
            },
            set (option) {
                this.$store.dispatch('setFilterOption', { selected: option, filter: this.name })
            }
        }
    },
    methods: {
        selectFilterOption (option) {
            this.selectedFilterOption = option
        }
    }

}
</script>

<style lang="scss" scoped>
    .weather-filters {
        &__label {
            border-bottom: 1px solid $grey-light;
            padding: 1.5rem;
            margin: 0;
        }
    }
</style>

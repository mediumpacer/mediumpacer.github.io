<template>
    <header class="weather__header">
        <nuxt-link v-if="isNotHome" :to="'/'" class="weather__header-back" />
        <h1 class="weather__header-title">
            Weather
        </h1>
        <div class="weather__header-updated">
            <div>Last updated: {{ $moment(requestDate).format('h:mma DD MMMM YYYY') }}</div>
            <span class="weather__refresh" @click="refreshData">Refresh</span>
        </div>
    </header>
</template>

<script>
import { mapState } from 'vuex'

export default {
    computed: {
        ...mapState({
            requestDate: state => state.requestDate
        }),
        isNotHome () {
            return this.$route.path !== '/'
        }
    },
    methods: {
        refreshData () {
            this.$store.dispatch('getWeatherData')
        }
    }
}
</script>

<style lang="scss" scoped>
    .weather {
        &__header {
            &-container {
                width: 90vw;
                width: clamp(16rem, 90vw, 70rem);
                padding-bottom: 5rem;
                margin: 0 auto;
            }

            &-title {
                display: flex;
                align-items: center;
                justify-content: center;
                height: 5rem;
                color: $white;
                margin: 0;
                font-size: 2rem;
                background: $navy-blue;
                padding: 0 1.5rem;
            }

            &-updated {
                font-size: 1.4rem;
                text-align: center;
                padding: 1rem 2rem;
                border-bottom: 1px solid $grey-light;
                display: flex;
                justify-content: center;
                align-items: center;
            }

            &-back {
                display: block;
                width: 2rem;
                height: 2rem;
                position: absolute;
                top: 1.6rem;
                left: calc((100% - 90vw) / 2);
                border: 0;
                background: transparent;
                cursor: pointer;

                &::before {
                    content: '';
                    display: inline-block;
                    border-style: solid;
                    border-width: 0.3rem 0.3rem 0 0;
                    border-color: $white;
                    width: 1rem;
                    height: 1rem;
                    transform: rotate(-135deg);
                }

                @media (min-width: $mq-med) {
                    left: calc(((100% - 70rem) / 2) + 1rem);
                }
            }
        }

        &__refresh {
            color: $cyan;
            cursor: pointer;
            margin-left: 2rem;

            &:hover {
                text-decoration: underline;
            }
        }
    }
</style>
